package com.ynov.schooltag.delay

import com.ynov.schooltag.R
import java.util.*


data class Delay(val course : String ="Course Kotlin", val justified : Int = R.drawable.ic_assignment_turned_in_black_24dp, val duration : Int =10, val name : String = "Fabien"){
// int en Long
// date, timestamp en string
    var lateDate : Calendar = Calendar.getInstance()

    constructor( lateDate : Calendar ):this(){
        this.lateDate = lateDate;
    }
}