package com.ynov.schooltag.delay

import android.content.Context
import android.os.Bundle
import android.support.v4.app.Fragment
import android.support.v7.widget.LinearLayoutManager
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import com.ynov.schooltag.R
import kotlinx.android.synthetic.main.delays_fragment.*

class DelaysFragment : Fragment() {

    var items = Array<Delay>(3, { Delay() })

    companion object {

        fun newInstance(): DelaysFragment {
            return DelaysFragment()
        }
    }

    fun seedItems(){
        val courseArray = resources.getStringArray(R.array.course)
        for (k in 0..2) {
            if(k==2) items[k] = Delay(courseArray[k],R.drawable.ic_assignment_late_black_24dp)
            else items[k] = Delay(courseArray[k], R.drawable.ic_assignment_turned_in_black_24dp, (k+1*10))
        }
    }

    override fun onCreateView(inflater: LayoutInflater,
                              container: ViewGroup?,
                              savedInstanceState: Bundle?): View? {
        seedItems()
        return inflater.inflate(R.layout.delays_fragment, container, false)
    }

    override fun onAttach(context: Context?) {
        super.onAttach(context)
       // recyclerView.layoutManager = LinearLayoutManager(context)
        // recyclerView.adapter = DelaysAdapter(items)
    }

    override fun onActivityCreated(savedInstanceState: Bundle?) {
        super.onActivityCreated(savedInstanceState)
        recyclerView.layoutManager = LinearLayoutManager(context)
        recyclerView.adapter = DelaysAdapter(items)
    }

}